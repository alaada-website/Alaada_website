from setuptools import setup, find_packages

setup(
    name="Alada",  # MUST be unique on PyPI
    version="1.0.0",
    description="This software has been developed by Arzo Das, a passionate and innovative developer dedicated to creating tools that empower users through intuitive design and powerful functionality.Published under the banner of Alada, this application embodies the organization's commitment to excellence in digital solutions.With a vision rooted in simplicity, accuracy, and user-centric development, Alada is proud to present this spreadsheet program as a cornerstone of smart business tools.ALADA – Where Precision Meets Possibility",
    long_description_content_type="text/markdown",
    author="Arzo Das",
    author_email="arzodas2024@gmail.com",
    packages=find_packages(),
    install_requires=['tkinter', 'tkinter', 'pandas','numpy' ,'re' ,'matplotlib.pyplot','tksheet', 'math', 'openai', 'os', 'logging'],
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
)
